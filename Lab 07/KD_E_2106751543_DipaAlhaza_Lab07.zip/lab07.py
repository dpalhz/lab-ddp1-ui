data = []

Countr = True # counter looping
while Countr:    
    jadwal = input("Selamat datang! Silakan masukkan jadwal KA: ") # mweminta user menginpust, yaitu format input pasti benar, <nomor_ka> <tujuan_akhir> <jam_keberangkatan> <harga_tiket>
    if jadwal == "selesai":
        print()
        while True:
            print("Perintah yang tersedia:"+"\n"+"1. INFO_TUJUAN"+"\n"+"2. TUJUAN_KELAS <tujuan_akhir> <kelas_kereta>"+"\n"  +"3. TUJUAN_JAM <tujuan_akhir> <jam_keberangkatan>"+"\n"+"4. EXIT")
            perintah = input("Masukkan perintah: ")
            if perintah == "INFO_TUJUAN": # jika user memilih "INFO_TUJUAN"
                set1 = set() # SET
                for i in data: # Memasukan data ke set
                    set1.add(i[1])
                print("KA di stasiun ini memiliki tujuan akhir: " )
                for i in set1: # menampilkan elemen set
                    print(i)
                print()
            elif perintah == "EXIT": # Program berakhir
                print("Terima kasih sudah menggunakan program ini!")
                Countr = False
                exit()
            perintah = perintah.split() # membagi setiap kata menjadi elemen list
               
            if perintah[0] == "TUJUAN_KELAS": # Konsisi jika perintah user "TUJUAN_KELAS"
                if perintah[2] == "Eksekutif": # kondisi kelas kereta
                    helplst = list()   # LIST        
                    for i in data:
                        if 100 <=int(i[0]) < 200: # syarat nomor ka
                            helplst.append(i) # Memasukan data ke list bantu
                    jumlah = 0
                    for j in helplst: #
                        if perintah[1] in j:
                            out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                            print(out)
                            jumlah += 1
                        elif perintah[1] not in j:
                            continue
                    if jumlah == 0: # kondisi jika tidak ditemukan jadwal
                        print("Tidak ada jadwal KA yang sesuai")

                    print()
                elif perintah[2] == "Bisnis": # konsep sama seperti diatas, cuma yang membedakan ialah no ka,unutk kelas Bisnis
                    helplst1 = list()                    
                    for i in data:
                        if 200 <=int(i[0]) < 300: # syarat no ka
                            helplst1.append(i)
                    jumlah = 0
                    for j in helplst1:
                        if perintah[1] in j:
                            out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                            print(out)
                            jumlah += 1
                        elif perintah[1] not in j:
                            continue
                    if jumlah == 0:
                        print("Tidak ada jadwal KA yang sesuai")
                    print()
                elif perintah[2] == "Ekonomi":  # konsep sama seperti diatas, cuma yang membedakan ialah no ka, untuk kelas ekonomi
                    helplst2 = list()                     
                    for i in data:
                        if 200 <=int(i[0]) < 300: # syarat nomor ka
                            helplst2.append(i)
                    jumlah = 0
                    for j in helplst2:
                        if perintah[1] in j:
                            out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                            print(out)
                            jumlah += 1
                        elif perintah[1] not in j:
                            continue
                    if jumlah == 0:
                        print("Tidak ada jadwal KA yang sesuai")
                    print()
                else:
                    print("Perintah yang dimasukkan tidak valid")

            elif perintah[0] == "TUJUAN_JAM": # Konsisi jika perintah user "TUJUAN_JAM"
                mydict = dict() # DICT
                for i in data: # memasukan data ke dict
                    if i[1] in mydict: 
                        mydict[i[1]] += 1
                    else:
                        mydict[i[1]] = 1
                if perintah[1] in mydict: # kondisi jika inputan user <tujuan_akhir> ada di dict
                    helplst3 = list() # helping list
                    for i in data:
                        helplst3.append(i) # Memasukan data ke helping list               
                    cnt = 0
                    for j in helplst3: # looping untuk mencetak jadwal berdasarkan <tujuan_akhir> dan jam maksimum berangkat
                        if perintah[1] in j:
                            if int(j[2]) <= int(perintah[2]):
                                out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                print(out)
                                cnt += 1
                        elif perintah[1] not in helplst3:
                            print("Tidak ada jadwal KA yang sesuai")
                            print()
                    if cnt == 0:
                        print("Tidak ada jadwal KA yang sesuai")
                    print()
                if perintah[1] not in mydict: # jika perintah user <tujuan_akhir> tidak ada
                    print("Tidak ada jadwal KA yang sesuai")
                    print()                                                    
    else:
        lst = jadwal.split() # mengubah inputan jadwal menjadi list
        data.append(lst) # memasukan kedalam data-list
 

            


