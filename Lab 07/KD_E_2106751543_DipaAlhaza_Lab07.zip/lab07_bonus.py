data = []

Countr = True
while Countr:
    try: # hanya untuk testing error pengerjaan
        jadwal = input("Selamat datang! Silakan masukkan jadwal KA: ")
        if jadwal == "selesai":
            print()
            while True:
                print("Perintah yang tersedia:"+"\n"+"1. INFO_TUJUAN"+"\n"+"2. TUJUAN_KELAS <tujuan_akhir> <kelas_kereta>"+"\n"+ "3. TUJUAN_KELAS_TERMURAH <tujuan_akhir> <kelas_kereta>"+"\n"  +"4. TUJUAN_JAM <tujuan_akhir> <jam_keberangkatan>"+'\n'+"5. TUJUAN_JAM_TERMURAH <tujuan_akhir> <jam_keberangkatan>"+"\n"+"6. EXIT")
                perintah = input("Masukkan perintah: ")
                if perintah == "INFO_TUJUAN":
                    set1 = set()
                    for i in data:
                        set1.add(i[1])
                    print("KA di stasiun ini memiliki tujuan akhir: " )
                    for i in set1:
                        print(i)
                    print()
                elif perintah == "EXIT":
                    print("Terima kasih sudah menggunakan program ini!")
                    Countr = False
                    exit()
                perintah = perintah.split()
               
                if perintah[0] == "TUJUAN_KELAS":
                    if perintah[2] == "Eksekutif":
                        helplst = list()                     
                        for i in data:
                            if 100 <=int(i[0]) < 200:
                                helplst.append(i)
                        jumlah = 0
                        for j in helplst:
                            if perintah[1] in j:
                                out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                print(out)
                                jumlah += 1
                            elif perintah[1] not in j:
                                continue
                        if jumlah == 0:
                            print("Tidak ada jadwal KA yang sesuai")

                        print()
                    elif perintah[2] == "Bisnis":
                        helplst1 = list()                    
                        for i in data:
                            if 200 <=int(i[0]) < 300:
                                helplst1.append(i)
                        jumlah = 0
                        for j in helplst1:
                            if perintah[1] in j:
                                out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                print(out)
                                jumlah += 1
                            elif perintah[1] not in j:
                                continue
                        if jumlah == 0:
                            print("Tidak ada jadwal KA yang sesuai")
                        print()
                    elif perintah[2] == "Ekonomi":
                        helplst2 = list()                     
                        for i in data:
                            if 200 <=int(i[0]) < 300:
                                helplst2.append(i)
                        jumlah = 0
                        for j in helplst2:
                            if perintah[1] in j:
                                out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                print(out)
                                jumlah += 1
                            elif perintah[1] not in j:
                                continue
                        if jumlah == 0:
                            print("Tidak ada jadwal KA yang sesuai")
                        print()
                    else:
                        print("Perintah yang dimasukkan tidak valid")

                elif perintah[0] == "TUJUAN_JAM":
                    mydict = dict()
                    for i in data:
                        if i[1] in mydict: 
                            mydict[i[1]] += 1
                        else:
                            mydict[i[1]] = 1
                    if perintah[1] in mydict:
                        helplst3 = list()
                        for i in data:
                            helplst3.append(i)                       
                        cnt = 0
                        for j in helplst3:
                            if perintah[1] in j:
                                if int(j[2]) <= int(perintah[2]):
                                    out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                    print(out)
                                    cnt += 1
                            elif perintah[1] not in helplst3:
                                print("Tidak ada jadwal KA yang sesuai")
                                print()
                        if cnt == 0:
                            print("Tidak ada jadwal KA yang sesuai")
                        print()
                    if perintah[1] not in mydict:
                        print("Tidak ada jadwal KA yang sesuai")
                        print()
                        # KONSEP YANG DIATAS KOMENNYA SAMA DENGAN Lab07.py

                     # konsep obsi bonus hampir sama dengan yang diatas, yang beda hanya ada langkah sorted list berdasarkan harga.
                elif perintah[0] == "TUJUAN_KELAS_TERMURAH": # Merkomendasikan dengan harga termurah
                    if perintah[2] == "Eksekutif":
                        helplst = list()     
                        for i in data:
                            if 100 <=int(i[0]) < 200:
                                helplst.append(i)
                        helplst = sorted(helplst, key= lambda y:(int(y[3]))) # menyerted list berdasarkan harga tiket                
                        for j in helplst:
                            if perintah[1] in j:
                                out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                print(out)
                                jumlah += 1
                                break
                        if jumlah == 0:
                            print("Tidak ada jadwal KA yang sesuai")

                        print()
                    elif perintah[2] == "Bisnis":
                        helplst1 = list()                    
                        for i in data:
                            if 200 <=int(i[0]) < 300:
                                helplst1.append(i)
                        helplst1 = sorted(helplst1, key= lambda y:(int(y[3])))
                        jumlah = 0
                        for j in helplst1:
                            if perintah[1] in j:
                                out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                print(out)
                                jumlah += 1
                                break
                            elif perintah[1] not in j:
                                continue
                        if jumlah == 0:
                            print("Tidak ada jadwal KA yang sesuai")
                        print()

                    elif perintah[2] == "Ekonomi":
                        helplst2 = list()                     
                        for i in data:
                            if 200 <=int(i[0]) < 300:
                                helplst2.append(i)
                        helplst2 = sorted(helplst2, key= lambda y:(int(y[3])))
                        jumlah = 0
                        for j in helplst2: # mengeluarkan jadwal dengan harga terendah
                            if perintah[1] in j:
                                out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                print(out)
                                jumlah += 1
                                continue
                            elif perintah[1] not in j:
                                continue
                        if jumlah == 0:
                            print("Tidak ada jadwal KA yang sesuai")
                        print()
                    else:
                        print("Perintah yang dimasukkan tidak valid")
                      
                elif perintah[0] == "TUJUAN_JAM_TERMURAH": # Opsi tambahan merekomendasikan dengan harga termurah
                    mydict = dict()
                    for i in data:
                        if i[1] in mydict: 
                            mydict[i[1]] += 1
                        else:
                            mydict[i[1]] = 1
                        
                    if perintah[1] in mydict:
                        helplst3 = list() # list mengkopi data jadwal
                        for i in data:
                            helplst3.append(i)
                        helplst3 = sorted(helplst3, key= lambda y:(int(y[3]))) # menyorted list berdasarkan harga tiket    
                        helplist4 = list()                   
                        cnt = 0
                        for j in helplst3: # mengeluar kan jadwal dengan harga terendah
                            if perintah[1] in j:
                                if int(j[2]) <= int(perintah[2]):
                                    out = "KA {:^3} berangkat pukul {:<2} dengan harga tiket {}".format(j[0],j[2],j[3])
                                    print(out)
                                    cnt += 1
                                    break                           
                        if cnt == 0:
                            print("Tidak ada jadwal KA yang sesuai")
                        print()
                    if perintah[1] not in mydict:
                        print("Tidak ada jadwal KA yang sesuai")
                        print()
                else:
                    print('Perintah yang dimasukkan tidak valid')
                    print()                         
        else:
            lst = jadwal.split()  # mengubah inputan jadwal menjadi list
            data.append(lst) # memasukan kedalam data-list
 

            

    except:
        pass
