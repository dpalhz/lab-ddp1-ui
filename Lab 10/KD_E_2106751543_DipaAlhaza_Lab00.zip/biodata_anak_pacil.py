
print ("Biodata Anak Pacil 2021") # Mencetak judul dari Program ini
print("\r") # nambah baris kosong
# Mengambil input dari pengguna dan
# menyimpannya kedalam variabel-variabel
nama = input("Nama : ")
alamat = input("Alamat : ")
tanggal_lahir = (input("Tanggal Lahir : "))
hobi = input("Hobi : ")
email = input("Email : ")
jurusan = input("jurusan = " )
print()# nambah baris kosong
# Mencetak isi dari variabel-variabel
print('Biodataku :')
print(5*'=')# nambah aksesoris biar rapi
print(nama)
print(alamat)
print(tanggal_lahir)
print(hobi)
print(email)
print(jurusan)
print("=====")# nambah aksesoris biar rapi
