PROMPT = "Masukkan rantai penyebaran:" # hanya tampilan 
CMD_PROMPT = """List perintah:
1. RANTAI_PENYEBARAN 
2. CEK_PENULARAN 
3. EXIT
"""
orang_tertular_utama = [] # membuat list menyimpan data
def data_person(): # function untuk meminta inputan
    data = list() # menyimpan data
    while True:
        str_input = input()
        if str_input.lower() == "selesai":
            print("")
            break
        else: 
            data.append(str_input.split())
    return data # mereturn data yang sudah dimasukan agar bisa diakses

def do_rantai_penyebaran(orang_tertular): # helping function untuk menyalin data dari recursive function
    global orang_tertular_utama
    for i in orang_tertular:
        orang_tertular_utama.append(orang_tertular)

def rantai_penyebaran(nama_penular, data): # recursive function untuk mengecek mata rantai penyebaran
    orang_tertular = [] # menyimpan data orang yang tertular dari si penular
    for i in data:
        if nama_penular in i[0]:
            for j in  i[1::]:
                orang_tertular.append(j)
        else: continue
    do_rantai_penyebaran(orang_tertular) # mengirim data ke helping function 
    for j in data: 
        if j[0] in orang_tertular: # kembali mengecek apakah orang yang tertular juga menularkan ke yang lain
            rantai_penyebaran(j[0],data) # kembali memakai function ini

cntr = True
while cntr:
    print(PROMPT)
    data = data_person() # mengambil data dari function data_person()
    while cntr:
        print(CMD_PROMPT)
        perintah = input("Masukkan perintah: ")
        perintah = perintah.split() # memisahkan kata dengan split()
        nama_terinfeksi = list() # nama terinfeksi khusus untuk penular
        for i in data:
            nama_terinfeksi.append(i[0])

        if perintah[0] == "RANTAI_PENYEBARAN": # kondisi 1
            nama_penular = perintah[1]
            if nama_penular in nama_terinfeksi:
                rantai_penyebaran(nama_penular,data) # mengirim data ke recursive function
                print("Rantai penyebaran {}:".format(nama_penular))
                orang_terjangkit = set() # menyimpan data orang yang terinveksi yang berakar atau disebabkan oleh dari si penular(perantara pertama)
                orang_terjangkit.add(nama_penular) # memasukan penular dalam himpunan orang terjangkit
                for i in orang_tertular_utama:
                    for j in i:
                        orang_terjangkit.add(j)
                else:
                    for i in orang_terjangkit: # menampilkan orang terjangkit karena si penular
                        print(i)
                    orang_tertular_utama.clear() # mereset kembali data
            elif nama_penular not in nama_terinfeksi:
                print("Maaf, nama {} tidak ada dalam rantai penyebaran.".format(nama_penular))
            print("")
            

        elif perintah[0] == "CEK_PENULARAN": # kondisi 2
            nama_tertular = perintah[1]
            nama_penular = perintah[2]
            if nama_penular in nama_terinfeksi:
                rantai_penyebaran(nama_penular,data) # mengirim data ke recursive function
                orang_terjangkit = set() # data terjangkit
                orang_terjangkit.add(nama_penular)
                for i in orang_tertular_utama:
                    for j in i:
                        orang_terjangkit.add(j)
                if nama_tertular in orang_terjangkit: # kondisi mengecek apakah benar si x tertular oleh y
                    print("IYA")
                elif nama_tertular not in orang_terjangkit:
                    print("TIDAK")
                orang_tertular_utama.clear()
            elif nama_penular not in nama_terinfeksi:
                print("Maaf, nama {} tidak ada dalam rantai penyebaran.".format(nama_penular))
            print("")
            
        elif perintah[0] == "EXIT": # keluar dari program
            print("Goodbye~ Semoga virus KOPIT cepat berakhir.")
            cntr = False
            break

        else: # inputan tidak sesuai
            print("Maaf perintah tidak dikenali. Masukkan perintah yang valid.")
            print("")

